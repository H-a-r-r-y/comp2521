class Multiply():
        def multiply(self, a, b):
                return a*b

        def display(self):
                print(self.multiply(5,5))
 

pdt = Multiply()
pdt.display()
