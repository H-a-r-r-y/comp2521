class Employee(object):
    
    # This class groups business rules and persistence
    
    def calculate_pay(self):
        # some business logic to calculate pay

    def save(self):
        # code to persist(store) employee details
