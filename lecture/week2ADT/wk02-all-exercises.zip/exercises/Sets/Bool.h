// Bool.h ... simple boolean data type
// Written by John Shepherd, August 2015

#ifndef BOOL_H
#define BOOL_H

#define FALSE 0
#define TRUE 1

#endif
