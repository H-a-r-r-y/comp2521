from server import app, valid_time
from flask import request, render_template
from Calculator import Calculator


@app.route('/', methods=['POST', 'GET'])
def interest_total():
    if request.method == 'POST':
        initial = request.form["amount"]
        rate = request.form["rate"]
        years = request.form["time"]
        if initial.isdigit() and rate.isdigit() and years.isdigit():
            comment = "Here is your Total Interest"
            initial = int(initial)
            rate = int(rate)
            years = int(years)
            
        else:
            comment = "Type error"
            render_template('interest_form.html',message = comment)
        
        ans = Calculator(initial, rate)
        total_interest = ans.total_interest(years)
        return render_template("interest_form.html", total = total_interest,message = comment)
    return render_template('interest_form.html', calc_total=True)


@app.route('/time', methods=['POST', 'GET'])
def time_interest():
    if request.method == 'POST':
        initial = request.form["amount"]
        rate = request.form["rate"]
        total = request.form["total"]
        if initial.isdigit() and rate.isdigit() and total.isdigit():
            comment = "Here is your Investment Time"
            initial = int(initial)
            rate = int(rate)
            total = int(total)
        else:
            comment = "Type error"
            render_template("interest_form.html",message = comment)
        
        ans = Calculator(initial, rate)
        total_years = ans.time_required(total)
        return render_template("interest_form.html", time = total_years,message = comment)
    return render_template('interest_form.html', calc_total=True)



@app.route('/credits', methods=['GET'])
def credits():
    return render_template('credits.html')
